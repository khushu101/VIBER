# i can fix ur playlist 🔪

A Gen Z playlist recommender built with Python + Streamlit.  
Answer 5 unhinged questions → get your one perfect song via cosine similarity + Claude roast.

## what's actually happening (the DS part)

1. **Tag vectorization** — each answer maps to a vibe tag. user answers become a binary vector across 20 possible tags.
2. **Cosine similarity** — user vector is compared against every song's tag vector in the database. closest match wins.
3. **LLM layer** — Claude generates a personalized roast explaining why that song fits, referencing the user's specific tags.

This is a simplified version of how real recommendation systems work (Spotify, Netflix etc.) — just without collaborative filtering or user history.

## setup

```bash
# 1. clone / download the folder

# 2. install dependencies
pip install -r requirements.txt

# 3. set your Anthropic API key
export ANTHROPIC_API_KEY=your_key_here
# on Windows: set ANTHROPIC_API_KEY=your_key_here

# 4. run
streamlit run app.py
```

App opens at http://localhost:8501

## files

```
playlist_fixer/
├── app.py           # main Streamlit UI + flow
├── recommender.py   # cosine similarity engine
├── songs_db.py      # song database with tags + metadata
├── requirements.txt
└── README.md
```

## how to extend this (for the ALLEN role)

- **add more songs** to `songs_db.py` — the recommender scales automatically
- **replace tag vectors with real embeddings** — swap `vectorize_tags()` in `recommender.py` with `sentence-transformers` embeddings for richer matching
- **add user history** — store past answers in a CSV/DB and use collaborative filtering
- **RAG pipeline** — give Claude the full song database as context instead of just the top match
